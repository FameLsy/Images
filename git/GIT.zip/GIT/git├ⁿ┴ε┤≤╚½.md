---
title: git命令大全
tags: 
- git
categories: 
- git
---
# 安装命令
**centos**:   
```linux
sudo yum install git
```
**unbuntu**
```linux
sudo apt-get install git
```
# 配置相关命令
```
git config
```
**系统级别的配置**（文件位于 */etc/gitconfig*)  
使用 *--system* 选项
```
 git config --system user.name "Fame Lee"
 git config --system user.email famelee@example.com
```

**当前用户级别的配置**（文件位于 *~/.gitconfig或 ~/.config/git/config* )  
使用 *--global*选项
```
 git config --global user.name "Fame Lee"
 git config --global user.email famelee@example.com
```

**当前仓库级别的配置**（文件位于 *.git/config* )
```
 git config user.name "Fame Lee"
 git config user.email famelee@example.com
 ```

**查看配置列表**  
使用选项 *--list*
```
git config --list
```
**查看特定配置**
```
git config user.name
```
**修改文本编辑器**
```
git config --global core.editor vim
```
# 帮助文档
```
 git help <verb>
 git <verb> --help
 man git-<verb>
```
# 获取仓库
**在现有目录中初始化仓库**
```
git init
```
**克隆现有的仓库**
```
# 克隆仓库到当前目录，仓库名默认
git clone https://github.com/demo/demo
# 自定义本地仓库名字
git clone https://github.com/demo/demo mydemo
```
# 文件状态/修改信息查看
**查看文件状态**
```
git status
```
**紧凑输出文件状态**
```git
git status -s
#或者
git status --short
```

注意：具体可以查看git-status解析文章  


**查看尚未暂存的文件更新**  
```git
git diff
```
**查看已暂存的将要添加到下次提交里的内容**
```git
git diff --cached
#或者，git16.1版本后适用
git diff --staged
```
# 文件暂存

```
git add [file-name]
git add [path]
```
# 文件提交
**提交更新**
```
git commit
```
**提交命令，并在提交更新文档显示git diff信息**  
```
git commit -v
```
**提交更新，并输入提交信息**
```git
git commit -m "提交信息"
```
**自动暂存追踪文件并提交**  
```
git commit -a
```
# 移除文件
**删除跟踪状态，且同时删除工作区的的文件（未暂存）。**
```git
git rm file
```
**强制删除已暂存的文件**
```git
git rm -f file
```
**删除暂存区中的文件，不删除工作区的文件**
```git
git rm --cached file
```
